var class_c_unit =
[
    [ "cal_con_tail", "class_c_unit.html#af3c79eec6228714fee1a782deba3adc1", null ],
    [ "compare_to_old", "class_c_unit.html#a531833a2e108c1f2b50ff5ef88b5a4fe", null ],
    [ "init", "class_c_unit.html#a292d4a6fdb97054fb3802c9fe0929eee", null ],
    [ "reset", "class_c_unit.html#a9fe770b942e413a4a7352e0296cd24ba", null ],
    [ "setId", "class_c_unit.html#a0551305cac04c6e1d8737bdcbfcdcb68", null ],
    [ "transf_con", "class_c_unit.html#a2c1dde629500134e05c279bff1dd1f65", null ],
    [ "transf_tail", "class_c_unit.html#afa8fd539b7c35a50596bfdb99f79760c", null ],
    [ "conc_gor_rate", "class_c_unit.html#a1189344cde9f0e9ea962e6643de9b858", null ],
    [ "conc_num", "class_c_unit.html#acdc8636ac295d38228496f681b1b87ce", null ],
    [ "conc_waste_rate", "class_c_unit.html#a85b32fd346ea18f7d682b24479c9c388", null ],
    [ "feed_gor_rate", "class_c_unit.html#a611aba82331dd5eb5b0e66263f4b0f51", null ],
    [ "feed_waste_rate", "class_c_unit.html#aaeb021b6f892c5c2cab20bedbbc0b1cf", null ],
    [ "mark", "class_c_unit.html#a18aec3c4d21ec8fbf30d4f5f81ff2412", null ],
    [ "old_feed_rate", "class_c_unit.html#acbaed974d919cad74b5f0af4b53ebce7", null ],
    [ "reachConcentrate", "class_c_unit.html#a9e77548d740f11b452c05d5c8ae9925f", null ],
    [ "reachTailings", "class_c_unit.html#a762fd091116ab8c6ecd19abea2e4ff04", null ],
    [ "tails_gor_rate", "class_c_unit.html#a23ba675418b27d39a65a9c10b8a152a0", null ],
    [ "tails_num", "class_c_unit.html#a18f9b08b44f3f38d4483406fdf73c356", null ],
    [ "tails_waste_rate", "class_c_unit.html#a0ce40c5019e3d87b8f313b29726d9fc7", null ]
];