var searchData=
[
  ['tails_5fgor_5frate_108',['tails_gor_rate',['../class_c_unit.html#a23ba675418b27d39a65a9c10b8a152a0',1,'CUnit']]],
  ['tails_5fnum_109',['tails_num',['../class_c_unit.html#a18f9b08b44f3f38d4483406fdf73c356',1,'CUnit']]],
  ['tails_5fwaste_5frate_110',['tails_waste_rate',['../class_c_unit.html#a0ce40c5019e3d87b8f313b29726d9fc7',1,'CUnit']]]
];
