var indexSectionsWithContent =
{
  0: "acdefgimnoprstuw",
  1: "cs",
  2: "cgm",
  3: "acdefgimoprstu",
  4: "cfgmnoprtw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

