var searchData=
[
  ['solution_57',['solution',['../classsolution.html',1,'']]]
];
