var searchData=
[
  ['same_5fvector_44',['same_vector',['../_genetic___algorithm_8cpp.html#a3ea86b82629398d918283db20ccef662',1,'same_vector(int *v1, int *v2):&#160;Genetic_Algorithm.cpp'],['../_genetic___algorithm_8h.html#a3ea86b82629398d918283db20ccef662',1,'same_vector(int *v1, int *v2):&#160;Genetic_Algorithm.cpp']]],
  ['selection_45',['selection',['../_genetic___algorithm_8cpp.html#a80b4a869da8f8b509ead28d2a1b62404',1,'selection(solution *pop):&#160;Genetic_Algorithm.cpp'],['../_genetic___algorithm_8h.html#a80b4a869da8f8b509ead28d2a1b62404',1,'selection(solution *pop):&#160;Genetic_Algorithm.cpp']]],
  ['setid_46',['setId',['../class_c_unit.html#a0551305cac04c6e1d8737bdcbfcdcb68',1,'CUnit']]],
  ['solution_47',['solution',['../classsolution.html',1,'']]],
  ['sort_5fpop_48',['sort_pop',['../_genetic___algorithm_8cpp.html#a6777f774627744c047cfa8e1a1d08562',1,'sort_pop(solution *pop):&#160;Genetic_Algorithm.cpp'],['../_genetic___algorithm_8h.html#a6777f774627744c047cfa8e1a1d08562',1,'sort_pop(solution *pop):&#160;Genetic_Algorithm.cpp']]]
];
