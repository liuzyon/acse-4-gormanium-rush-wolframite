var searchData=
[
  ['transf_5fcon_89',['transf_con',['../class_c_unit.html#a2c1dde629500134e05c279bff1dd1f65',1,'CUnit']]],
  ['transf_5ftail_90',['transf_tail',['../class_c_unit.html#afa8fd539b7c35a50596bfdb99f79760c',1,'CUnit']]]
];
