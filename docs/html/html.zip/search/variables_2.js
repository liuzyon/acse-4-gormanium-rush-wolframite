var searchData=
[
  ['gor_5fprice_101',['gor_price',['../_c_circuit_8h.html#a4e9eff2bbc9e1605c7d9a6f61f8ff77d',1,'CCircuit.h']]]
];
