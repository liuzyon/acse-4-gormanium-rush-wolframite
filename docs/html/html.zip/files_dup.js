var files_dup =
[
    [ "CCircuit.cpp", "_c_circuit_8cpp.html", "_c_circuit_8cpp" ],
    [ "CCircuit.h", "_c_circuit_8h.html", "_c_circuit_8h" ],
    [ "CUnit.cpp", "_c_unit_8cpp.html", null ],
    [ "CUnit.h", "_c_unit_8h.html", [
      [ "CUnit", "class_c_unit.html", "class_c_unit" ]
    ] ],
    [ "Genetic_Algorithm.cpp", "_genetic___algorithm_8cpp.html", "_genetic___algorithm_8cpp" ],
    [ "Genetic_Algorithm.h", "_genetic___algorithm_8h.html", "_genetic___algorithm_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];