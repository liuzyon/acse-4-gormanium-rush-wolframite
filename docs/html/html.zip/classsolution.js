var classsolution =
[
    [ "curit_vector", "classsolution.html#a9567b9a0f4f24668b647cf29c79a327f", null ],
    [ "fitness_value", "classsolution.html#afcd38ff3d5ee6363ee5ba2a74a4e212d", null ]
];